import sys
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import col

args = getResolvedOptions(sys.argv, ["RAW_BUCKET", "PROCESSED_BUCKET"])
raw_bucket = args["RAW_BUCKET"]
processed_bucket = args["PROCESSED_BUCKET"]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

df = spark.read.option("header", "true").csv(f"s3://{raw_bucket}/sales/")
df_clean = (
    df.dropna()
      .withColumn("amount", col("amount").cast("double"))
      .withColumn("tax", col("amount") * 0.1)
)

df_clean.write.mode("overwrite").parquet(f"s3://{processed_bucket}/sales/")
